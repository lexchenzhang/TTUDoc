package project;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

class Dialog_exit extends JDialog{
    
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	Dialog_exit(JFrame parent, String title){
        super(parent, title, false);
        setLayout(new FlowLayout());
        setSize(300, 200);
        JButton addBtn = new JButton("Exit"); 
        add(addBtn);
        addBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	System.exit(0);
            }
        });
    }
}