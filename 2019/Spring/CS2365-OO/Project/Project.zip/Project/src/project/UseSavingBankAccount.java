package project;

public class UseSavingBankAccount{
	public static SavingAccount account_arr[];
	
	public static void initAccounts() {
		account_arr = new SavingAccount[50];
		for (int i=0;i<50;i++) {
			account_arr[i] = new SavingAccount((i+1),"Student","TTU"+(i+1),i%2==0?'C':'S',i*10*0.5,5.0);
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		initAccounts();
		GUI gui = new GUI();
		gui.init();
	}
}
