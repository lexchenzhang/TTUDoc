package project;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

class Dialog_alter_name extends JDialog{
    
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	Dialog_alter_name(JFrame parent, String title){
        super(parent, title, false);
        init();
    }
	
	private void init() {
		setLayout(new FlowLayout());
		
    	JLabel lb1 = new JLabel("Account Type");
        JLabel lb2 = new JLabel("String To Append");
        
        JTextField tf1;
        JTextField tf2;
        tf1 = new JTextField(10);
        tf2 = new JTextField(10);
        setSize(300, 200);
        JButton btn = new JButton("Submit");
        
        btn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	String txt = tf2.getText();
            	if (txt.length() > 0) {
            		if (tf1.getText().length() > 0) {
            			char type = tf1.getText().toUpperCase().charAt(0);
                    	alterNames(UseSavingBankAccount.account_arr, type, txt);
                    	Account.displayAll(UseSavingBankAccount.account_arr);
            		}else {
            			JOptionPane.showMessageDialog(null, "Please input the type of account. (C/S)");
            		}
            	}else {
            		JOptionPane.showMessageDialog(null, "Please input the append string.");
            	}
            }
        });
        
        Box box = Box.createVerticalBox();
        Box mid = Box.createHorizontalBox();
        Box box_left = Box.createVerticalBox();
        Box box_right = Box.createVerticalBox();
        Box box_bottom = Box.createVerticalBox();
        
        box_left.add(lb1);
        box_left.add(lb2);
        
        box_right.add(tf1);
        box_right.add(tf2);
        
        box_bottom.add(btn);
        
        mid.add(box_left);
        mid.add(Box.createHorizontalStrut(20));
        mid.add(box_right);
        box.add(mid);
		box.add(Box.createVerticalStrut(50));
		box.add(box_bottom);
		
		add(box);
    }
	
	private void alterNames(SavingAccount[] arr, char accountType, String txt) {
		for (int i=0;i<arr.length;i++) {
			if (arr[i].getAccountType() == accountType) {
				arr[i].appendName(txt);
			}
		}
	}
}