package project;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Comparator;

import javax.swing.*;

class Dialog_display_all extends JDialog{
    /**
	 * display account after sorting.
	 */
	private static final long serialVersionUID = 1L;
    
    Dialog_display_all(JFrame parent, String title){
        super(parent, title, false);
        init();
    }
    
    private void init() {
    	setLayout(new FlowLayout());
    	
    	JLabel lb1 = new JLabel("Account Type");
        JLabel lb2 = new JLabel("String To Append");
        
        JTextField tf1;
        JTextField tf2;
        tf1 = new JTextField(10);
        tf2 = new JTextField(10);
        setSize(300, 200);
        JButton btn = new JButton("Submit");
        
        btn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	if (tf1.getText().length() > 0) {
            		char type = tf1.getText().toUpperCase().charAt(0);
                	sortByBalanceDes(UseSavingBankAccount.account_arr, type);
                	Account.displayAll(UseSavingBankAccount.account_arr);
            	}else {
                	JOptionPane.showMessageDialog(null, "Please input the type of account. (C/S)");
                }
            }
        });
        
        Box box = Box.createVerticalBox();
        Box mid = Box.createHorizontalBox();
        Box box_left = Box.createVerticalBox();
        Box box_right = Box.createVerticalBox();
        Box box_bottom = Box.createVerticalBox();
        
        box_left.add(lb1);
        box_left.add(lb2);
        
        box_right.add(tf1);
        box_right.add(tf2);
        
        box_bottom.add(btn);
        
        mid.add(box_left);
        mid.add(Box.createHorizontalStrut(20));
        mid.add(box_right);
        box.add(mid);
		box.add(Box.createVerticalStrut(50));
		box.add(box_bottom);
		
		add(box);
    }
    
    private void sortByBalanceDes(SavingAccount arr[], char accountType) {
    	ArrayList<SavingAccount> list1 = new ArrayList<SavingAccount>();
    	ArrayList<SavingAccount> list2 = new ArrayList<SavingAccount>();
    	for (int i=0;i<arr.length;i++) {
    		if(arr[i].getAccountType() == accountType) {
    			list1.add(arr[i]);
    		}
    	}
    	for (int i=0;i<arr.length;i++) {
    		if(arr[i].getAccountType() != accountType) {
    			list2.add(arr[i]);
    		}
    	}
    	list1.sort(new Comparator<SavingAccount>() {
			@Override
			public int compare(SavingAccount o1, SavingAccount o2) {
				return o1.getBalance() < o2.getBalance() ? 1 : -1;
			}
		});
    	list2.sort(new Comparator<SavingAccount>() {
			@Override
			public int compare(SavingAccount o1, SavingAccount o2) {
				return o1.getBalance() < o2.getBalance() ? 1 : -1;
			}
		});
    	for (int i=0;i<list1.size();i++) {
    		UseSavingBankAccount.account_arr[i] = list1.get(i);
    	}
    	for (int i=0;i<list2.size();i++) {
    		UseSavingBankAccount.account_arr[list1.size()+i] = list2.get(i);
    	}
//    	for (int i=0;i<arr.length;i++) {
//    		System.out.println(UseSavingBankAccount.account_arr[i].getID()+" "+UseSavingBankAccount.account_arr[i].getAccountType()+" "+UseSavingBankAccount.account_arr[i].getBalance());
//    	}
    }
}