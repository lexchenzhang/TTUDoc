package project;

public class SavingAccount extends Account {
	private double rate;

	SavingAccount(int id, String lname, String fname, char type, double balance, double rate) {
		super(id,lname,fname,type,balance);
		this.rate = rate;
	}

	public boolean addInterest() {
		if (accountType == 'S') {
			balance += balance*rate;
			return true;
		}
		return false;
	}

	public void deductLoan(double amount) {
		withdraw(amount);
	}

}
