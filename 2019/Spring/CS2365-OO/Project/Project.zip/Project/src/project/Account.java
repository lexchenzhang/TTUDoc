package project;
import javax.swing.JOptionPane;

public class Account {
	protected int id;
	protected Customer customer;
	protected char accountType;
	protected double balance;

	public void setID(int id) {
		this.id = id;
	}

	public int getID() {
		return this.id;
	}

	public void setName(String fname, String lname) {
		customer.setLName(lname);
		customer.setFName(fname);
	}
	
	public void setFName(String fname) {
		customer.setFName(fname);
	}
	
	public void appendName(String str) {
		customer.setFName(customer.getFName()+str);
	}

	public String getName() {
		return customer.getFName() + " " + customer.getLName();
	}

	public void setAccountType(char type) {
		this.accountType = type;
	}

	public char getAccountType() {
		return this.accountType;
	}

	public void setBalance(double blance) {
		this.balance = blance;
	}

	public double getBalance() {
		return this.balance;
	}

	Account() {
		this.customer = new Customer("aaa", "bbb");
		this.accountType = 'C';
		this.balance = 0.0;
	}

	Account(int id, String fname, String lname, char type, double balance) {
		this.id = id;
		this.customer = new Customer(lname, fname);
		this.accountType = type;
		this.balance = balance;
	}

	public void withdraw(double amount) {
		if(balance >= amount) {
			balance-=amount;
		}else {
			JOptionPane.showMessageDialog(null, "Insufficient balance.");
		}
	}

	public void deposit(double amount) {
		balance+=amount;
	}

	public void displayBalance() {
		JOptionPane.showMessageDialog(null, "The balance is "+balance);
	}

	public static void displayAll(Account[] arr) {
		String str = "";
		for (int i=0;i<arr.length;i++) {
			str += arr[i].getID() + " " + arr[i].getName() + " " +arr[i].getAccountType() + " " +arr[i].getBalance() + "\n";
		}
		JOptionPane.showMessageDialog(null, str);
	}
}
