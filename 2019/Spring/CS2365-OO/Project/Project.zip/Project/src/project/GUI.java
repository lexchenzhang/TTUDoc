package project;

import java.awt.FlowLayout;
import java.awt.event.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.*;

public class GUI extends JFrame {
	
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private JMenu jMenu;
    private JMenuBar jMenuBar;
    private JMenuItem jMenuItem1;
    private JMenuItem jMenuItem2;
    private JMenuItem jMenuItem3;
    private JMenuItem jMenuItem4;
	
	public GUI() {
		
	}
	
	public void init() {
		setLayout(new FlowLayout());
		setSize(500, 300);
		initMenu();
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	private void initMenu() {
		jMenu = new javax.swing.JMenu();
        jMenuBar = new javax.swing.JMenuBar();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenuItem3 = new javax.swing.JMenuItem();
        jMenuItem4 = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jMenu.setText("Options");

        jMenuItem1.setText("DisplayAll");
        jMenuItem1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                jMenuItemDisplayActionPerformed(evt);
            }
        });
        
        jMenuItem2.setText("AlterName");
        jMenuItem2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                jMenuItemAlterActionPerformed(evt);
            }
        });
        
        jMenuItem3.setText("Convert");
        jMenuItem3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                jMenuItemConvertActionPerformed(evt);
            }
        });
        
        jMenuItem4.setText("Exit");
        jMenuItem4.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
            	jMenuItemExitActionPerformed(evt);
            }
        });
        
        jMenu.add(jMenuItem1);
        jMenu.add(jMenuItem2);
        jMenu.add(jMenuItem3);
        jMenu.add(jMenuItem4);

        jMenuBar.add(jMenu);

        setJMenuBar(jMenuBar);
	}
	
	private void jMenuItemDisplayActionPerformed(ActionEvent evt) {
        Dialog_display_all d = new Dialog_display_all(this, "Dialog Display All");
        d.setVisible(true);
    }
	
	private void jMenuItemAlterActionPerformed(ActionEvent evt) {
        Dialog_alter_name d = new Dialog_alter_name(this, "Dialog Alter Name");
        d.setVisible(true);
    }
	
	private void jMenuItemConvertActionPerformed(ActionEvent evt) {
        Dialog_convert d = new Dialog_convert(this, "Dialog Convert");
        d.setVisible(true);
    }
	
	private void jMenuItemExitActionPerformed(ActionEvent evt) {
		Dialog_exit d = new Dialog_exit(this, "Dialog Exit");
        d.setVisible(true);
    }
	
	public boolean isNumeric(String str){
        Pattern pattern = Pattern.compile("[0-9]*");
        Matcher isNum = pattern.matcher(str);
        if( !isNum.matches() ){
            return false;
        }
        return true;
	}
}
