package project;
public class Customer {
	private String strLName;
	private String strFName;
	
	Customer(String lname, String fname) {
		this.strLName = lname;
		this.strFName = fname;
	}
	
	public void setLName(String lname) {
		this.strLName = lname;
	}
	
	public void setFName(String fname) {
		this.strFName = fname;
	}
	
	public String getLName() {
		return this.strLName;
	}
	
	public String getFName() {
		return this.strFName;
	}
}
