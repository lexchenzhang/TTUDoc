#ifndef SHELL_H
#define SHELL_H

void execute(char* const args[]);

#endif //SHELL_H
